<?php
    echo"<h3>Datalar geldi</h3>";
    $cins="";
 if ($_POST['cinsiyet']==0){
    $cins="Erkek";
 }else if ($_POST['cinsiyet']==1){
    $cins="Kadın";
 }
 $cins=array(0=>"erkek",1=>"kadın");
 //$cins2=array("erkek","kadın");
// $renkler=$array(5=>"yeşil","siyah","mor");
 echo $cins[1];
 $sehirler=array(34=>"İstanbul",41=>"Kocaeli",54=>"Sakarya");
//$sehirler[$_POST["sehir"]];

//her seferinde posttan gelen datalar varmı diye kontol edilmeli

$renkler="";
$renkler2="";

/* doğru bir yöntem değil
 if ($_POST["renk"][0])
    $renkler+=" "+$_POST["renk"][0];
*/
for($i=0;$i<count($_POST["renk"]);$i++){
    $renkler=$renkler.$_POST["renk"][$i]." ";
}

foreach($_POST['renk'] as $value){
    $renkler2=$renkler2." ".$value;
}
 
    echo"<pre>";
    print_r($_POST);
    echo"<hr>";
   // var $a ="cam";
   // $a=5;
   /*
   echo $_GET["ad"];
   echo"<br>";
   echo $_GET["soyad"];
   */
   echo "<b>Adınız:</b>". $_POST["ad"];
   echo"<br>";
   echo "<b>Soyadınız:</b>".$_POST["soyad"];
   echo"<br>";
   echo "<b>Cinsiyet:</b>".$cins[$_POST['cinsiyet']];
   echo"<br>";
   echo "<b>Renkler:</b> ".$renkler;
   echo"<br>";
   echo"<b>Sehir:</b>".$sehirler[$_POST["sehir"]];
   echo"<br>";
   echo"<b>Adres:</b>".$_POST["adres"];
   echo"<br>";
   echo"<b>Saat:</b>".$_POST["saat"];
   echo"<br>";
   echo"<b>Tarih:</b>". $_POST["tarih"];

   echo"<br><br>";

   echo "Adınız:". $_POST["ad"]."<br>"."Soyadınız:". $_POST["soyad"]."<br>". "<b>Renkler:</b> ".$renkler;

?>

<h1>MErhaba</h1>
<?php

    
?>